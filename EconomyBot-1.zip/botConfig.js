module.exports = {
    token: "Nzc5MzYzMTE0MDM3NjczOTg0.X7fcdg.WlqP8X5EVbDmt_JeSGHAfH4vgdY",
    prefix: "-b",
    admins: [
        "PEOPLE WHO CAN USE ADD MONEY (IDS)"
],
    debug: true,
    countChannel: "countChannelID"
};
