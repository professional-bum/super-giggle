# EconomyBot
**This Economy bot was created by 0_0#6666**

**IN BOTCONFIG.JSON DO NOT CHANGE ANY VARIABLE THE CountChannel var is for if you want to set a channel to count for users if not just leave it blank AND EVERYTHING ELSE IS SELF EPLAINATORY JUST CHANGE THE VALUES 
INSIDE "" TO MAKE YOUR BOT FUNCTION PROPERLY!**
# Links
- 🔗 [Youtube Channel](https://www.youtube.com/channel/UCF9E-xef9jL9QgziZRDHKKQ)
- [Support Server Link](https://discord.gg/REAW5VM)
# Copyright 
Copyright 2020 © All RIghts are Reserved | If you are using any part of code please give me credits for the same. Thanks

# License
**nginx 2020 all rights reserved**

**NOTE FOR GLITCH HOSTERS 
`` THIS BOT DOES NOT DIE IT SENDS A HEARTBEAT (PING) EVERY 5 MINS TO THE GLITCH PROJECT SO THAT YOUR PROJECT STAYS ALIVE IF IT DOES NOT WORK FOR YOU THEN 
DM ME FOR A SCRIPT THAT PREVENTS THIS JOIN THE SERVER ABOVE AND DM  ME @0_0#6666 THIS MIGHT GET YOUR PROJECT SUSPENDED BUT YOU CAN ALWAYS
MAKE A NEW ONE USING MY TUTORIAL :D``**
``IT WORKS ON REPL.IT PRETTY FINE ITS BEEN TESTED ALREADY``

# Host On Repl.it
[![Use on Repl.it](https://repl.it/badge/github/ZeroDiscord/EconomyBot)](https://repl.it/github/ZeroDiscord/EconomyBot)
# Host On Glitch 
[Click Here to Host On Glitch](https://glitch.com/edit/#!/import/git?url=https://github.com/ZeroDiscord/EconomyBot/)

# Dependencies 
*Discord.js v12
*quick.db
*quick.eco
