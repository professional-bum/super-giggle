module.exports = (client) => {
    console.log(`${client.user.tag} is online!`);
  client.user.setActivity("biscuit will be ashamed of you");
};
