const { MessageEmbed } = require("discord.js");

exports.execute = async (client, message, args) => {
  let userBalance = client.eco.fetchMoney(message.author.id);
  if (userBalance.amount < 1) return message.channel.send("Are you serious? You don't have enoguh b points! Be ashamed you foul scum! If biscuit finds out how POOR you are, your fucked..");
  let item = args[0];
  if (!item) return message.channel.send("What are you trying to buy?");
  let hasItem = client.shop[item.toLowerCase()];
  if (!hasItem || hasItem == undefined) return message.reply("bish are you retarded, that doesn't fucking exist.");
  let isBalanceEnough = (userBalance.amount >= hasItem.cost);
  if (!isBalanceEnough) return message.reply("damn your poor as fuck,you need  "+hasItem.cost+" b points  to buy this, you filthy rat. You are the source of poverty in this world.");
  let buy = client.eco.removeMoney(message.author.id, hasItem.cost);
  
  let itemStruct = {
    name: item.toLowerCase(),
    prize: hasItem.cost
  };
  
  client.db.push(`items_${message.author.id}`, itemStruct);
  return message.channel.send(`Yay, you finally fucking bought someting,you got **${item}** for ${hasItem.cost} b boints.`);
};

exports.help = {
  name: "buy",
  aliases: [],
  usage: `buy <item>`
};
