exports.execute = async (client, message, args) => {
    let users = [
        "PewDiePie",
        "T-Series",
        "Sans",
        "Zero"
    ];
    let amount = Math.floor(Math.random() * 50) + 10;
    let beg = client.eco.beg(client.ecoAddUser, amount, { canLose: true });
    if (beg.onCooldown) return message.reply(`i cant give b points! come back after mmm  ${beg.time.seconds} seconds!`);
    if (beg.lost) return message.channel.send(`**${users[Math.floor(Math.random() * users.length)]}:** I cant give b points! come back a little mmm later!`);
    else return message.reply(`**${users[Math.floor(Math.random() * users.length)]}** donated you **${beg.amount}** b points. Now you have **${beg.after}** b points. Congrats child.`);
};

exports.help = {
    name: "beg",
    aliases: [],
    usage: "beg"
}
